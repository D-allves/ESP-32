#include <WiFi.h>   // Permite usar internet Wi-Fi
#include <WiFiClientSecure.h>  // Permite conexão segura (tipo HTTPS)
#include <PubSubClient.h>   // Permite usar MQTT (mensagens pela internet)

#define ID_MQTT "SENAI_IOT01"  // Nome do dispositivo no MQTT
#define pubSensor1IotSenai "Sensor1IotSenai"  // Nome de envio (não usado aqui)
#define subLed1IotSenai "Led1IotSenai"  // Nome para receber comando do LED
#define USERNAME_MQTT "SENAI_IOT01_web_client"   // Usuário do MQTT
#define PASSWORD_MQTT "Aa123456789"  // Senha do MQTT
#define LED_PIN 25  // Pino do LED

const char* SSID = "Wokwi-GUEST"; // Nome do Wifi
const char* BROKER_MQTT = "e47ac4e2db9749458638cc5ae98e85bf.s1.eu.hivemq.cloud";  // Endereço do servidor MQTT

WiFiClientSecure wifiClient;  // Cria conexão segura com internet
PubSubClient MQTT(wifiClient);  // Cria sistema MQTT usando a internet


bool ledState = false;  // Tipo que retorna verdadeiro ou falso (ligado ou desligado)

void setLed(bool estado) {
  digitalWrite(LED_PIN, estado ? HIGH : LOW);  // Liga ou desliga o LED
}
}

void callback(char* topic, byte* payload, unsigned int length) {  // Cria uma variável pra guardar a mensagem
  String msg;
  for (unsigned int i = 0; i < length; i++) msg += (char)payload[i];   // Junta os pedaços da mensagem recebida

  bool novoEstado = (msg == "1" || msg == "ON");   // Se a mensagem for "1" ou "ON", liga o LED
  ledState = novoEstado;  // Salva o estado
  setLed(ledState);  // Liga ou desliga o LED
  Serial.println("LED " + String(ledState ? "ON" : "OFF") + " (MQTT)");  // Mostra no monitor se o LED está ON ou OFF
}

void setup() {
  Serial.begin(115200);  // Liga o monitor serial

  delay(1000); // Espera um pouco

  pinMode(LED_PIN, OUTPUT);  // Define o pino do LED como saída
  digitalWrite(LED_PIN, LOW);  // Começa com LED desligado

  WiFi.begin(SSID, "");  // Conecta no Wi-Fi
  wifiClient.setInsecure();
  MQTT.setServer(BROKER_MQTT, 8883);  // Define o servidor MQTT
  MQTT.setCallback(callback);  // Define o que fazer quando chegar mensagem
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {  // Se não estiver conectado no Wi-Fi

    delay(500);  // Espera
    return;  // Sai e tenta de novo depois
  }

  if (!MQTT.connected()) {  // Se não estiver conectado no MQTT
    if (MQTT.connect(ID_MQTT, USERNAME_MQTT, PASSWORD_MQTT)) {   // Tenta conectar
      MQTT.subscribe(subLed1IotSenai);  // Se conecta e começa a ouvir o tópico
      Serial.println("MQTT OK");  // Mostra que deu certo
    }
  }

  MQTT.loop();  // Fica verificando se chegou mensagem
}